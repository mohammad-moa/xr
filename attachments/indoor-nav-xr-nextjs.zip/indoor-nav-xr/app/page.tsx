'use client';
import { useState, useRef, useEffect, useMemo } from 'react';

type NodeKind = 'origin' | 'destination' | 'waypoint';
type MapNode = { id: string; x: number; y: number; kind: NodeKind; name: string };
type Edge = [string, string];
type FloorPlan = { imgSrc: string | null; imgDims: { w: number; h: number }; nodes: MapNode[]; edges: Edge[]; idCounter: number };

const STORAGE_KEY = 'floorplan-v1';
const KIND_COLOR: Record<NodeKind, string> = { origin: '#173430', destination: '#1d7a6e', waypoint: '#9db0ac' };
const KIND_LABEL: Record<NodeKind, string> = { origin: 'مبدأ', destination: 'مقصد', waypoint: '' };

const dist = (a: { x: number; y: number }, b: { x: number; y: number }) => Math.hypot(a.x - b.x, a.y - b.y);
const headingFor = (a: { x: number; y: number }, b: { x: number; y: number }) =>
  ((Math.atan2(b.x - a.x, -(b.y - a.y)) * 180) / Math.PI + 360) % 360;
const norm = (n: number) => ((n % 360) + 360) % 360;
const signed = (n: number) => { const x = norm(n); return x > 180 ? x - 360 : x; };

function shortestPath(nodes: MapNode[], edges: Edge[], startId: string, endId: string): MapNode[] {
  const byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
  const adj: Record<string, { to: string; w: number }[]> = {};
  nodes.forEach((n) => (adj[n.id] = []));
  edges.forEach(([a, b]) => {
    if (!byId[a] || !byId[b]) return;
    const w = dist(byId[a], byId[b]);
    adj[a].push({ to: b, w });
    adj[b].push({ to: a, w });
  });
  const distMap: Record<string, number> = {};
  const prev: Record<string, string> = {};
  const visited = new Set<string>();
  nodes.forEach((n) => (distMap[n.id] = Infinity));
  if (!(startId in distMap)) return [];
  distMap[startId] = 0;
  while (visited.size < nodes.length) {
    let u: string | null = null;
    let best = Infinity;
    for (const n of nodes) if (!visited.has(n.id) && distMap[n.id] < best) { best = distMap[n.id]; u = n.id; }
    if (u === null) break;
    visited.add(u);
    if (u === endId) break;
    for (const { to, w } of adj[u] || []) {
      const alt = distMap[u] + w;
      if (alt < distMap[to]) { distMap[to] = alt; prev[to] = u; }
    }
  }
  const path: string[] = [];
  let cur: string | undefined = endId;
  while (cur !== undefined) { path.unshift(cur); cur = prev[cur]; }
  return path[0] === startId ? path.map((id) => byId[id]) : [];
}

function loadPlan(): FloorPlan {
  if (typeof window === 'undefined') return { imgSrc: null, imgDims: { w: 800, h: 500 }, nodes: [], edges: [], idCounter: 1 };
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { imgSrc: null, imgDims: { w: 800, h: 500 }, nodes: [], edges: [], idCounter: 1 };
}

export default function Page() {
  const [view, setView] = useState<'edit' | 'navigate'>('edit');
  const [plan, setPlan] = useState<FloorPlan>({ imgSrc: null, imgDims: { w: 800, h: 500 }, nodes: [], edges: [], idCounter: 1 });
  const [loaded, setLoaded] = useState(false);

  useEffect(() => { setPlan(loadPlan()); setLoaded(true); }, []);
  useEffect(() => {
    if (!loaded) return;
    try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(plan)); } catch {}
  }, [plan, loaded]);

  return (
    <div>
      <div style={{ display: 'flex', background: '#fff', borderBottom: '1px solid #e5ecea', position: 'sticky', top: 0, zIndex: 10 }}>
        {(['edit', 'navigate'] as const).map((key) => (
          <button
            key={key}
            onClick={() => setView(key)}
            style={{
              flex: 1, padding: '13px 0', border: 'none', background: 'transparent',
              borderBottom: view === key ? '2px solid #1d7a6e' : '2px solid transparent',
              color: view === key ? '#1d7a6e' : '#8a9895', fontSize: 13.5, fontWeight: view === key ? 600 : 400, cursor: 'pointer',
            }}
          >
            {key === 'edit' ? 'ویرایش نقشه' : 'ناوبری'}
          </button>
        ))}
      </div>
      {view === 'edit' ? <EditView plan={plan} setPlan={setPlan} /> : <NavigateView plan={plan} />}
    </div>
  );
}

function EditView({ plan, setPlan }: { plan: FloorPlan; setPlan: (p: FloorPlan) => void }) {
  const [mode, setMode] = useState<'addOrigin' | 'addDestination' | 'addWaypoint' | 'connect' | 'delete'>('addWaypoint');
  const [connectFrom, setConnectFrom] = useState<string | null>(null);
  const [editingNode, setEditingNode] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        setPlan({ ...plan, imgSrc: ev.target?.result as string, imgDims: { w: img.naturalWidth, h: img.naturalHeight } });
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  }

  function pointFromEvent(e: React.MouseEvent) {
    const svg = svgRef.current!;
    const rect = svg.getBoundingClientRect();
    return {
      x: Math.round(((e.clientX - rect.left) / rect.width) * plan.imgDims.w),
      y: Math.round(((e.clientY - rect.top) / rect.height) * plan.imgDims.h),
    };
  }

  function handleCanvasClick(e: React.MouseEvent) {
    if (!plan.imgSrc || mode === 'connect' || mode === 'delete') return;
    const { x, y } = pointFromEvent(e);
    const kind: NodeKind = mode === 'addOrigin' ? 'origin' : mode === 'addDestination' ? 'destination' : 'waypoint';
    if (kind === 'origin' && plan.nodes.some((n) => n.kind === 'origin')) { alert('فقط یک مبدأ مجاز است.'); return; }
    const id = 'n' + plan.idCounter;
    const newNode: MapNode = { id, x, y, kind, name: '' };
    setPlan({ ...plan, nodes: [...plan.nodes, newNode], idCounter: plan.idCounter + 1 });
    if (kind !== 'waypoint') setEditingNode(id);
  }

  function handleNodeClick(node: MapNode, e: React.MouseEvent) {
    e.stopPropagation();
    if (mode === 'delete') {
      setPlan({
        ...plan,
        nodes: plan.nodes.filter((n) => n.id !== node.id),
        edges: plan.edges.filter(([a, b]) => a !== node.id && b !== node.id),
      });
      return;
    }
    if (mode === 'connect') {
      if (!connectFrom) setConnectFrom(node.id);
      else if (connectFrom === node.id) setConnectFrom(null);
      else {
        const exists = plan.edges.some(([a, b]) => (a === connectFrom && b === node.id) || (a === node.id && b === connectFrom));
        if (!exists) setPlan({ ...plan, edges: [...plan.edges, [connectFrom, node.id]] });
        setConnectFrom(null);
      }
      return;
    }
    if (node.kind !== 'waypoint') setEditingNode(node.id);
  }

  function updateNodeName(id: string, name: string) {
    setPlan({ ...plan, nodes: plan.nodes.map((n) => (n.id === id ? { ...n, name } : n)) });
  }

  function exportJSON() {
    const origin = plan.nodes.find((n) => n.kind === 'origin');
    const destinations = plan.nodes.filter((n) => n.kind === 'destination').map((n) => ({ id: n.id, name: n.name || n.id, x: n.x, y: n.y }));
    const routeNodes = plan.nodes.filter((n) => n.kind === 'waypoint').map((n) => ({ id: n.id, x: n.x, y: n.y }));
    const data = { mapName: 'Custom Floor Plan', imageSize: plan.imgDims, origin: origin ? { id: origin.id, name: origin.name || 'مبدأ', x: origin.x, y: origin.y } : null, destinations, routeNodes, edges: plan.edges };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'map.json'; a.click();
    URL.revokeObjectURL(url);
  }

  const originExists = plan.nodes.some((n) => n.kind === 'origin');

  return (
    <div style={{ padding: 14, maxWidth: 780, margin: '0 auto' }}>
      {!plan.imgSrc && (
        <label style={{ display: 'block', position: 'relative', border: '2px dashed #cfe0dc', borderRadius: 16, padding: '40px 16px', textAlign: 'center', cursor: 'pointer', background: '#fff' }}>
          <div style={{ fontSize: 28 }}>⬆</div>
          <div style={{ fontSize: 13.5, color: '#324b47', marginTop: 8 }}>برای آپلود نقشه (PNG / JPG) اینجا بزن</div>
          <input type="file" accept="image/*" onChange={handleUpload} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }} />
        </label>
      )}

      {plan.imgSrc && (
        <>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 10 }}>
            {([
              ['addOrigin', 'مبدأ QR', originExists],
              ['addDestination', 'مقصد', false],
              ['addWaypoint', 'نقطه مسیر', false],
              ['connect', 'اتصال', false],
              ['delete', 'حذف', false],
            ] as const).map(([key, label, disabled]) => (
              <button key={key} disabled={disabled} onClick={() => { setMode(key); setConnectFrom(null); }}
                style={{ padding: '7px 11px', borderRadius: 10, border: mode === key ? '1px solid #1d7a6e' : '1px solid #d8e3e0', background: disabled ? '#eef2f1' : mode === key ? '#1d7a6e' : '#fff', color: disabled ? '#b9c8c4' : mode === key ? '#fff' : '#324b47', fontSize: 12, cursor: disabled ? 'default' : 'pointer' }}>
                {label}
              </button>
            ))}
            <button onClick={exportJSON} style={{ marginRight: 'auto', padding: '7px 12px', borderRadius: 10, border: 'none', background: '#2f6fed', color: '#fff', fontSize: 12, cursor: 'pointer' }}>
              دانلود JSON
            </button>
          </div>

          <div style={{ fontSize: 11.5, color: '#8a9895', marginBottom: 8 }}>
            {mode === 'connect' ? (connectFrom ? 'حالا نقطه‌ی دوم را بزن' : 'روی اولین نقطه بزن') : mode === 'delete' ? 'روی نقطه‌ای بزن که حذف میشه' : 'روی نقشه بزن تا نقطه اضافه شود'}
          </div>

          <div style={{ background: '#fff', borderRadius: 14, padding: 8, boxShadow: '0 1px 3px rgba(15,40,35,0.08)' }}>
            <svg ref={svgRef} viewBox={`0 0 ${plan.imgDims.w} ${plan.imgDims.h}`} onClick={handleCanvasClick}
              style={{ width: '100%', height: 'auto', display: 'block', cursor: mode === 'connect' || mode === 'delete' ? 'pointer' : 'crosshair', borderRadius: 8 }}>
              <image href={plan.imgSrc} x="0" y="0" width={plan.imgDims.w} height={plan.imgDims.h} />
              {plan.edges.map(([a, b], i) => {
                const na = plan.nodes.find((n) => n.id === a), nb = plan.nodes.find((n) => n.id === b);
                if (!na || !nb) return null;
                return <line key={i} x1={na.x} y1={na.y} x2={nb.x} y2={nb.y} stroke="#2f6fed" strokeWidth={Math.max(3, plan.imgDims.w / 200)} strokeLinecap="round" opacity={0.85} />;
              })}
              {plan.nodes.map((n) => (
                <g key={n.id} transform={`translate(${n.x},${n.y})`} onClick={(e) => handleNodeClick(n, e)} style={{ cursor: 'pointer' }}>
                  <circle r={Math.max(8, plan.imgDims.w / 90)} fill={connectFrom === n.id ? '#2f6fed' : KIND_COLOR[n.kind]} stroke="#fff" strokeWidth={Math.max(2, plan.imgDims.w / 300)} />
                  {n.kind !== 'waypoint' && (
                    <text y={-Math.max(14, plan.imgDims.w / 55)} textAnchor="middle" fontSize={Math.max(12, plan.imgDims.w / 55)} fill="#173430" style={{ fontWeight: 600, paintOrder: 'stroke', stroke: '#fff', strokeWidth: 3 }}>
                      {n.name || KIND_LABEL[n.kind]}
                    </text>
                  )}
                </g>
              ))}
            </svg>
          </div>

          <div style={{ marginTop: 12, fontSize: 11.5, color: '#5a6b68' }}>{plan.nodes.length} نقطه · {plan.edges.length} اتصال</div>
        </>
      )}

      {editingNode && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(11,18,16,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50, padding: 20 }}>
          <div style={{ background: '#fff', borderRadius: 16, padding: 18, width: '100%', maxWidth: 300 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <span style={{ fontSize: 14, fontWeight: 600 }}>نام‌گذاری نقطه</span>
              <span style={{ cursor: 'pointer', color: '#8a9895' }} onClick={() => setEditingNode(null)}>✕</span>
            </div>
            <input autoFocus type="text" placeholder="مثلا: رادیولوژی" defaultValue={plan.nodes.find((n) => n.id === editingNode)?.name || ''}
              onChange={(e) => updateNodeName(editingNode, e.target.value)}
              style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '1px solid #d8e3e0', fontSize: 13.5, boxSizing: 'border-box' }} />
            <button onClick={() => setEditingNode(null)} style={{ width: '100%', marginTop: 12, padding: 10, borderRadius: 10, border: 'none', background: '#1d7a6e', color: '#fff', fontSize: 13.5, cursor: 'pointer' }}>تایید</button>
          </div>
        </div>
      )}
    </div>
  );
}

function NavigateView({ plan }: { plan: FloorPlan }) {
  const [destination, setDestination] = useState<MapNode | null>(null);
  const [travelled, setTravelled] = useState(0);
  const [heading, setHeading] = useState<number | null>(null);
  const [ready, setReady] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const originNode = plan.nodes.find((n) => n.kind === 'origin');
  const destinationNodes = plan.nodes.filter((n) => n.kind === 'destination');
  const pathNodes = useMemo(() => (originNode && destination ? shortestPath(plan.nodes, plan.edges, originNode.id, destination.id) : []), [originNode, destination, plan.nodes, plan.edges]);
  const totalLen = useMemo(() => { let t = 0; for (let i = 1; i < pathNodes.length; i++) t += dist(pathNodes[i - 1], pathNodes[i]); return t; }, [pathNodes]);

  useEffect(() => {
    function onOrient(e: DeviceOrientationEvent) {
      const x = e as DeviceOrientationEvent & { webkitCompassHeading?: number };
      if (typeof x.webkitCompassHeading === 'number') setHeading(norm(x.webkitCompassHeading));
      else if (typeof e.alpha === 'number') setHeading(norm(360 - e.alpha));
    }
    window.addEventListener('deviceorientation', onOrient, true);
    return () => window.removeEventListener('deviceorientation', onOrient, true);
  }, []);

  async function selectDestination(d: MapNode) {
    setDestination(d);
    setTravelled(0);
    try {
      const s = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false });
      streamRef.current = s;
      if (videoRef.current) { videoRef.current.srcObject = s; await videoRef.current.play(); }
      setReady(true);
    } catch { setReady(false); }
  }

  function exit() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    setDestination(null);
    setReady(false);
  }

  if (!originNode || destinationNodes.length === 0) {
    return <div style={{ padding: '40px 20px', textAlign: 'center', color: '#8a9895', fontSize: 13.5 }}>هنوز نقشه‌ای ساخته نشده — برو تب «ویرایش نقشه»، یک مبدأ (QR) و حداقل یک مقصد بگذار.</div>;
  }

  if (!destination) {
    return (
      <div style={{ padding: '18px 16px', maxWidth: 480, margin: '0 auto' }}>
        <h2 style={{ fontSize: 16, margin: '0 0 12px' }}>کجا می‌روی؟</h2>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {destinationNodes.map((d) => (
            <button key={d.id} onClick={() => selectDestination(d)} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', borderRadius: 12, border: '1px solid #d8e3e0', background: '#fff', fontSize: 13.5, color: '#173430', cursor: 'pointer', textAlign: 'right' }}>
              📍 {d.name || d.id}
            </button>
          ))}
        </div>
      </div>
    );
  }

  let acc = 0, legIndex = 1, from = pathNodes[0], to = pathNodes[1] || pathNodes[0];
  for (let i = 1; i < pathNodes.length; i++) {
    const legLen = dist(pathNodes[i - 1], pathNodes[i]);
    if (travelled < acc + legLen || i === pathNodes.length - 1) { legIndex = i; from = pathNodes[i - 1]; to = pathNodes[i]; break; }
    acc += legLen;
  }
  const overallRemaining = Math.max(0, totalLen - travelled);
  const targetBearing = headingFor(from, to);
  const arrowAngle = heading === null ? 0 : signed(targetBearing - heading);
  const arrived = overallRemaining < 0.3;

  return (
    <div style={{ position: 'relative', height: 'calc(100vh - 46px)', minHeight: 480, background: '#0b1210', overflow: 'hidden', color: '#fff' }}>
      <video ref={videoRef} muted playsInline style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', padding: 14, boxSizing: 'border-box' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <button onClick={exit} style={{ background: 'rgba(0,0,0,0.45)', border: 'none', color: '#fff', padding: '8px 14px', borderRadius: 999, fontSize: 12.5 }}>← خروج</button>
          <span style={{ background: 'rgba(0,0,0,0.45)', padding: '7px 12px', borderRadius: 999, fontSize: 11.5 }}>{ready ? '● دوربین فعال' : '○ در حال باز کردن...'}</span>
        </div>
        <div style={{ textAlign: 'center' }}>
          <div style={{ fontSize: 32, fontWeight: 700, marginBottom: 4 }}>{arrived ? 'رسیدید' : `${overallRemaining.toFixed(1)} m`}</div>
          <div style={{ fontSize: 56, transform: `rotate(${arrowAngle}deg)`, transition: 'transform 0.2s ease', marginBottom: 4 }}>↑</div>
          <div style={{ fontSize: 12, background: 'rgba(0,0,0,0.4)', display: 'inline-block', padding: '5px 12px', borderRadius: 999 }}>
            {arrived ? `رسیدید به ${destination.name}` : heading === null ? 'منتظر قطب‌نمای گوشی...' : `waypoint ${legIndex}/${pathNodes.length - 1}`}
          </div>
        </div>
        <button onClick={() => setTravelled((t) => Math.min(totalLen, t + 3.6))} style={{ width: '100%', padding: 11, borderRadius: 12, border: '1px solid rgba(255,255,255,0.25)', background: 'rgba(0,0,0,0.35)', color: '#fff', fontSize: 13 }}>
          🚶 شبیه‌سازی قدم (پیش‌نمایش)
        </button>
      </div>
    </div>
  );
}
