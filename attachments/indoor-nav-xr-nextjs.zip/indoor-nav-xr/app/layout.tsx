import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "راهیاب داخل ساختمان",
  description: "ویرایشگر نقشه و ناوبری زنده با دوربین",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
