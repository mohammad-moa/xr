# Indoor Nav — Editor + AR-ish Navigation (Next.js)

دو تب توی یک اپ:
- **ویرایش نقشه**: نقشه (PNG/JPG) رو آپلود می‌کنی، نقطه‌ی مبدأ (QR)، مقصدها و نقاط مسیر رو می‌ذاری و به هم وصل می‌کنی. خروجی JSON هم می‌تونی بگیری.
- **ناوبری**: مقصد رو انتخاب می‌کنی، دوربین باز میشه، مسیر (کوتاه‌ترین مسیر روی گراف، با Dijkstra) با فلش نشون داده میشه.

داده‌ها فعلاً توی `localStorage` مرورگر خود کاربر ذخیره میشه (بدون بک‌اند) — یعنی این نسخه برای دمو/تست روی یک گوشیه، نه برای اینکه چند نفر همزمان از یک نقشه استفاده کنن. برای نسخه‌ی واقعی چندکاربره باید این بخش با یک API (مثلاً NestJS) جایگزین بشه.

## اجرای محلی
```bash
npm install
npm run dev
```
برای تست دوربین/قطب‌نما روی گوشی، باید روی HTTPS اجرا بشه (یا با ngrok/localtunnel تانل بزنی روی HTTPS).

## پوش کردن به گیت‌هاب
```bash
cd indoor-nav-xr
git init
git add .
git commit -m "Initial commit: floor plan editor + camera-based navigation"
git branch -M main
git remote add origin https://github.com/mohammad-moa/xr.git
git push -u origin main
```

## دیپلوی روی Vercel یا Render
- **Vercel** (پیشنهاد می‌شه، چون خود Next.js رو ساختن و صفر تنظیمات لازمه): ریپو رو وصل کن، خودش تشخیص میده Next.jsه و دیپلوی می‌کنه.
- **Render**: نوع سرویس رو Web Service بذار، Build Command: `npm install && npm run build`، Start Command: `npm run start`.

هر دو به‌صورت پیش‌فرض HTTPS می‌دن، پس دوربین و قطب‌نما روی گوشی بعد از دیپلوی درست کار می‌کنه.
